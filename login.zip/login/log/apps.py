from django.apps import AppConfig


class LogConfig(AppConfig):
    name = 'log'
